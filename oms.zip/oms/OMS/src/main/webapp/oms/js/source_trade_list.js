(function(mini,window,jkUtils){
	
})(mini,window,jkUtils)