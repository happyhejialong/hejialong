/**
 * 
 */
/**
 * @author TF
 *
 */
package com.ycxy.wdgj.taobao.domain;