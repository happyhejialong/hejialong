package com.ycxy.wdgj.valid;

public interface update {

}
