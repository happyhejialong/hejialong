/**
 * Copyright(C) 2018 Hangzhou Differsoft Co., Ltd. All rights reserved.
 *
 */
package com.ycxy.wdgj.controller;

/**
 * @since 2018年2月12日 上午11:30:01
 * @author hjl
 *
 */
public class TradeOrderLogController {

}
