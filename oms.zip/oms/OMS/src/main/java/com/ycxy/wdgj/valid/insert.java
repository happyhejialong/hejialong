package com.ycxy.wdgj.valid;

public interface insert {

}
