/**
 * Copyright(C) 2018 Hangzhou Differsoft Co., Ltd. All rights reserved.
 *
 */
package com.ycxy.wdgj;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * springboot启动类
 * 
 * @since 2018年2月12日 上午11:56:37
 * @author hjl
 *
 */
@SpringBootApplication
@MapperScan("com.ycxy.wdgj.dao")
public class Application { 
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}
