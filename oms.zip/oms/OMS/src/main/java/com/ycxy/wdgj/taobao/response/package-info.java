/**
 * 
 */
/**
 * @author TF
 *
 */
package com.ycxy.wdgj.taobao.response;